const API_KEY = 'AIzaSyBjb6ZKYyXHX16QJejKyOEA6iHD_1HfrAs';

const CHANNEL_ID = 'UCBjRa_6mf-xTPQcXhVIde2A';

const videoContainer = document.getElementById('videoContainer');

const searchBar = document.getElementById('searchBar');

async function fetchVideos(query = '') {

    const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${CHANNEL_ID}&q=${query}&maxResults=10&type=video&key=${API_KEY}`;

    const response = await fetch(url);

    const data = await response.json();

    displayVideos(data.items);

}

function displayVideos(videos) {

    videoContainer.innerHTML = '';

    videos.forEach(video => {

        const videoElement = document.createElement('div');

        videoElement.classList.add('video');

        videoElement.innerHTML = `

            <iframe width="100%" height="200" src="https://www.youtube.com/embed/${video.id.videoId}" frameborder="0" allowfullscreen></iframe>

            <h3>${video.snippet.title}</h3>

        `;

        videoContainer.appendChild(videoElement);

    });

}

searchBar.addEventListener('input', (e) => {

    fetchVideos(e.target.value);

});

fetchVideos();