# Octa batch

A Pen created on CodePen.

Original URL: [https://codepen.io/tmpwkqnt-the-encoder/pen/GgRwpmR](https://codepen.io/tmpwkqnt-the-encoder/pen/GgRwpmR).

